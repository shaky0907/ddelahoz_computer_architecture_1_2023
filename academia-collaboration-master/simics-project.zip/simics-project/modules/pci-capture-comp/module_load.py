# This Software is part of Simics. The rights to copy, distribute,
# modify, or otherwise make use of this Software may be licensed only
# pursuant to the terms of an applicable license agreement.
#
# Copyright 2014-2021 Intel Corporation

from . import pci_capture_comp
pci_capture_comp.pci_capture_comp.register()
